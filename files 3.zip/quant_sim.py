#!/usr/bin/env python3
"""
Quantitative Trading Simulator
Fast, production-ready backtesting engine with CLI interface

Usage:
    python quant_sim.py --csv data.csv --strategy trend
    python quant_sim.py --csv data.csv --strategy trend --fast 10 --slow 30 --plot
    python quant_sim.py --csv data.csv --strategy meanrev --opt grid
"""

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
from datetime import datetime
import warnings

import pandas as pd
import numpy as np

warnings.filterwarnings('ignore')

# Optional imports
try:
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False


@dataclass
class Trade:
    """Single trade record"""
    entry_date: datetime
    exit_date: datetime
    entry_price: float
    exit_price: float
    shares: float
    pnl: float
    pnl_pct: float
    side: str  # 'LONG' or 'SHORT'
    exit_reason: str  # 'SIGNAL', 'STOP', 'TAKE_PROFIT'


@dataclass
class BacktestResult:
    """Backtest performance metrics"""
    total_return: float
    annual_return: float
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    max_drawdown_duration: int
    win_rate: float
    profit_factor: float
    total_trades: int
    winning_trades: int
    losing_trades: int
    avg_win: float
    avg_loss: float
    avg_trade: float
    largest_win: float
    largest_loss: float
    
    equity_curve: pd.Series = field(repr=False)
    trades: List[Trade] = field(repr=False)
    
    def print_summary(self):
        """Print formatted summary"""
        print("\n" + "="*80)
        print("BACKTEST RESULTS")
        print("="*80)
        
        print(f"\n📊 PERFORMANCE METRICS")
        print(f"  Total Return:        {self.total_return:>10.2f}%")
        print(f"  Annual Return:       {self.annual_return:>10.2f}%")
        print(f"  Sharpe Ratio:        {self.sharpe_ratio:>10.2f}")
        print(f"  Sortino Ratio:       {self.sortino_ratio:>10.2f}")
        print(f"  Max Drawdown:        {self.max_drawdown:>10.2f}%")
        print(f"  Max DD Duration:     {self.max_drawdown_duration:>10d} days")
        
        print(f"\n📈 TRADE STATISTICS")
        print(f"  Total Trades:        {self.total_trades:>10d}")
        print(f"  Winning Trades:      {self.winning_trades:>10d}")
        print(f"  Losing Trades:       {self.losing_trades:>10d}")
        print(f"  Win Rate:            {self.win_rate:>10.2f}%")
        print(f"  Profit Factor:       {self.profit_factor:>10.2f}")
        
        print(f"\n💰 TRADE METRICS")
        print(f"  Avg Win:             ${self.avg_win:>10.2f}")
        print(f"  Avg Loss:            ${self.avg_loss:>10.2f}")
        print(f"  Avg Trade:           ${self.avg_trade:>10.2f}")
        print(f"  Largest Win:         ${self.largest_win:>10.2f}")
        print(f"  Largest Loss:        ${self.largest_loss:>10.2f}")
        
        print("\n" + "="*80 + "\n")


class TechnicalIndicators:
    """Fast technical indicator calculations"""
    
    @staticmethod
    def sma(prices: pd.Series, period: int) -> pd.Series:
        """Simple Moving Average"""
        return prices.rolling(window=period).mean()
    
    @staticmethod
    def ema(prices: pd.Series, period: int) -> pd.Series:
        """Exponential Moving Average"""
        return prices.ewm(span=period, adjust=False).mean()
    
    @staticmethod
    def rsi(prices: pd.Series, period: int = 14) -> pd.Series:
        """Relative Strength Index"""
        delta = prices.diff()
        gain = delta.where(delta > 0, 0).rolling(window=period).mean()
        loss = -delta.where(delta < 0, 0).rolling(window=period).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))
    
    @staticmethod
    def atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
        """Average True Range"""
        tr1 = high - low
        tr2 = abs(high - close.shift())
        tr3 = abs(low - close.shift())
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        return tr.rolling(window=period).mean()
    
    @staticmethod
    def bollinger_bands(prices: pd.Series, period: int = 20, num_std: float = 2.0) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """Bollinger Bands"""
        sma = prices.rolling(window=period).mean()
        std = prices.rolling(window=period).std()
        upper = sma + (std * num_std)
        lower = sma - (std * num_std)
        return upper, sma, lower


class BacktestEngine:
    """High-performance backtesting engine"""
    
    def __init__(self, 
                 initial_capital: float = 100000,
                 commission: float = 0.001,
                 slippage: float = 0.0005):
        
        self.initial_capital = initial_capital
        self.commission = commission
        self.slippage = slippage
        
        self.cash = initial_capital
        self.position = 0
        self.position_price = 0
        
        self.equity_curve = []
        self.trades: List[Trade] = []
        
    def execute_trade(self, 
                     date: datetime,
                     price: float,
                     signal: int,
                     stop_loss: Optional[float] = None,
                     take_profit: Optional[float] = None,
                     position_size: float = 1.0) -> None:
        """Execute a trade based on signal"""
        
        # Close existing position
        if self.position != 0 and signal != np.sign(self.position):
            self._close_position(date, price, 'SIGNAL')
        
        # Open new position
        if signal != 0 and self.position == 0:
            self._open_position(date, price, signal, position_size, stop_loss, take_profit)
    
    def _open_position(self, 
                      date: datetime,
                      price: float,
                      signal: int,
                      position_size: float,
                      stop_loss: Optional[float],
                      take_profit: Optional[float]) -> None:
        """Open a new position"""
        
        # Apply slippage
        execution_price = price * (1 + self.slippage * signal)
        
        # Calculate shares
        position_value = self.cash * position_size
        shares = position_value / execution_price
        
        # Apply commission
        commission_cost = position_value * self.commission
        
        # Update state
        self.position = shares * signal
        self.position_price = execution_price
        self.cash -= (position_value + commission_cost)
        
        # Store for later closing
        self._entry_date = date
        self._stop_loss = stop_loss
        self._take_profit = take_profit
    
    def _close_position(self, date: datetime, price: float, reason: str) -> None:
        """Close existing position"""
        
        if self.position == 0:
            return
        
        # Apply slippage
        signal = -np.sign(self.position)
        execution_price = price * (1 + self.slippage * signal)
        
        # Calculate P&L
        position_value = abs(self.position) * execution_price
        commission_cost = position_value * self.commission
        
        gross_pnl = (execution_price - self.position_price) * self.position
        net_pnl = gross_pnl - commission_cost
        pnl_pct = (net_pnl / (abs(self.position) * self.position_price)) * 100
        
        # Record trade
        trade = Trade(
            entry_date=self._entry_date,
            exit_date=date,
            entry_price=self.position_price,
            exit_price=execution_price,
            shares=abs(self.position),
            pnl=net_pnl,
            pnl_pct=pnl_pct,
            side='LONG' if self.position > 0 else 'SHORT',
            exit_reason=reason
        )
        self.trades.append(trade)
        
        # Update cash
        self.cash += position_value - commission_cost
        
        # Reset position
        self.position = 0
        self.position_price = 0
    
    def check_stops(self, date: datetime, high: float, low: float, close: float) -> None:
        """Check stop loss and take profit"""
        
        if self.position == 0:
            return
        
        # Check stop loss
        if self._stop_loss is not None:
            if self.position > 0 and low <= self._stop_loss:
                self._close_position(date, self._stop_loss, 'STOP')
            elif self.position < 0 and high >= self._stop_loss:
                self._close_position(date, self._stop_loss, 'STOP')
        
        # Check take profit
        if self._take_profit is not None:
            if self.position > 0 and high >= self._take_profit:
                self._close_position(date, self._take_profit, 'TAKE_PROFIT')
            elif self.position < 0 and low <= self._take_profit:
                self._close_position(date, self._take_profit, 'TAKE_PROFIT')
    
    def update_equity(self, price: float) -> None:
        """Update equity curve"""
        position_value = abs(self.position) * price if self.position != 0 else 0
        total_equity = self.cash + position_value
        self.equity_curve.append(total_equity)
    
    def calculate_metrics(self, dates: pd.DatetimeIndex) -> BacktestResult:
        """Calculate performance metrics"""
        
        equity_series = pd.Series(self.equity_curve, index=dates)
        returns = equity_series.pct_change().dropna()
        
        # Performance metrics
        total_return = ((equity_series.iloc[-1] - self.initial_capital) / self.initial_capital) * 100
        
        # Annualized return
        days = (dates[-1] - dates[0]).days
        years = days / 365.25
        annual_return = (((equity_series.iloc[-1] / self.initial_capital) ** (1 / years)) - 1) * 100 if years > 0 else 0
        
        # Sharpe ratio
        if len(returns) > 1 and returns.std() > 0:
            sharpe_ratio = np.sqrt(252) * (returns.mean() / returns.std())
        else:
            sharpe_ratio = 0
        
        # Sortino ratio
        downside_returns = returns[returns < 0]
        if len(downside_returns) > 1 and downside_returns.std() > 0:
            sortino_ratio = np.sqrt(252) * (returns.mean() / downside_returns.std())
        else:
            sortino_ratio = 0
        
        # Drawdown
        running_max = equity_series.expanding().max()
        drawdown = (equity_series - running_max) / running_max * 100
        max_drawdown = drawdown.min()
        
        # Drawdown duration
        is_in_dd = drawdown < 0
        dd_periods = is_in_dd.astype(int).groupby((~is_in_dd).cumsum()).cumsum()
        max_dd_duration = dd_periods.max() if len(dd_periods) > 0 else 0
        
        # Trade statistics
        winning_trades = [t for t in self.trades if t.pnl > 0]
        losing_trades = [t for t in self.trades if t.pnl <= 0]
        
        total_trades = len(self.trades)
        win_rate = (len(winning_trades) / total_trades * 100) if total_trades > 0 else 0
        
        avg_win = np.mean([t.pnl for t in winning_trades]) if winning_trades else 0
        avg_loss = np.mean([t.pnl for t in losing_trades]) if losing_trades else 0
        avg_trade = np.mean([t.pnl for t in self.trades]) if self.trades else 0
        
        largest_win = max([t.pnl for t in winning_trades]) if winning_trades else 0
        largest_loss = min([t.pnl for t in losing_trades]) if losing_trades else 0
        
        # Profit factor
        gross_profit = sum([t.pnl for t in winning_trades])
        gross_loss = abs(sum([t.pnl for t in losing_trades]))
        profit_factor = (gross_profit / gross_loss) if gross_loss > 0 else 0
        
        return BacktestResult(
            total_return=total_return,
            annual_return=annual_return,
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            max_drawdown=max_drawdown,
            max_drawdown_duration=max_dd_duration,
            win_rate=win_rate,
            profit_factor=profit_factor,
            total_trades=total_trades,
            winning_trades=len(winning_trades),
            losing_trades=len(losing_trades),
            avg_win=avg_win,
            avg_loss=avg_loss,
            avg_trade=avg_trade,
            largest_win=largest_win,
            largest_loss=largest_loss,
            equity_curve=equity_series,
            trades=self.trades
        )


class TrendStrategy:
    """Trend following strategy with moving average crossover"""
    
    def __init__(self, 
                 fast_period: int = 20,
                 slow_period: int = 50,
                 atr_stop: float = 2.0,
                 risk_per_trade: float = 0.02):
        
        self.fast_period = fast_period
        self.slow_period = slow_period
        self.atr_stop = atr_stop
        self.risk_per_trade = risk_per_trade
    
    def generate_signals(self, data: pd.DataFrame) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """Generate trading signals"""
        
        # Calculate indicators
        fast_ma = TechnicalIndicators.sma(data['close'], self.fast_period)
        slow_ma = TechnicalIndicators.sma(data['close'], self.slow_period)
        atr = TechnicalIndicators.atr(data['high'], data['low'], data['close'])
        
        # Generate signals
        signals = pd.Series(0, index=data.index)
        signals[(fast_ma > slow_ma) & (fast_ma.shift(1) <= slow_ma.shift(1))] = 1  # Buy
        signals[(fast_ma < slow_ma) & (fast_ma.shift(1) >= slow_ma.shift(1))] = -1  # Sell
        
        # Calculate stops
        stop_loss = data['close'] - (atr * self.atr_stop)
        take_profit = data['close'] + (atr * self.atr_stop * 2)  # 2:1 risk/reward
        
        return signals, stop_loss, take_profit


class MeanReversionStrategy:
    """Mean reversion strategy using RSI"""
    
    def __init__(self,
                 rsi_period: int = 14,
                 buy_below: float = 30,
                 sell_above: float = 70,
                 stop_pct: float = 0.02):
        
        self.rsi_period = rsi_period
        self.buy_below = buy_below
        self.sell_above = sell_above
        self.stop_pct = stop_pct
    
    def generate_signals(self, data: pd.DataFrame) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """Generate trading signals"""
        
        # Calculate RSI
        rsi = TechnicalIndicators.rsi(data['close'], self.rsi_period)
        
        # Generate signals
        signals = pd.Series(0, index=data.index)
        signals[rsi < self.buy_below] = 1  # Oversold - buy
        signals[rsi > self.sell_above] = -1  # Overbought - sell
        
        # Calculate stops
        stop_loss = data['close'] * (1 - self.stop_pct)
        take_profit = data['close'] * (1 + self.stop_pct * 2)
        
        return signals, stop_loss, take_profit


def load_data(csv_path: str) -> pd.DataFrame:
    """Load and validate CSV data"""
    
    if not Path(csv_path).exists():
        raise FileNotFoundError(f"CSV file not found: {csv_path}")
    
    # Load data
    data = pd.read_csv(csv_path)
    
    # Validate required columns
    required = ['timestamp', 'open', 'high', 'low', 'close']
    missing = [col for col in required if col not in data.columns]
    
    if missing:
        raise ValueError(f"Missing required columns: {missing}\nRequired: {required}")
    
    # Parse timestamps
    data['timestamp'] = pd.to_datetime(data['timestamp'])
    data.set_index('timestamp', inplace=True)
    data.sort_index(inplace=True)
    
    return data


def run_backtest(data: pd.DataFrame, strategy_name: str, **kwargs) -> BacktestResult:
    """Run backtest with specified strategy"""
    
    # Initialize strategy
    if strategy_name == 'trend':
        strategy = TrendStrategy(
            fast_period=kwargs.get('fast', 20),
            slow_period=kwargs.get('slow', 50),
            atr_stop=kwargs.get('atr_stop', 2.0),
            risk_per_trade=kwargs.get('risk_per_trade', 0.02)
        )
    elif strategy_name == 'meanrev':
        strategy = MeanReversionStrategy(
            rsi_period=kwargs.get('rsi_period', 14),
            buy_below=kwargs.get('buy_below', 30),
            sell_above=kwargs.get('sell_above', 70),
            stop_pct=kwargs.get('stop_pct', 0.02)
        )
    else:
        raise ValueError(f"Unknown strategy: {strategy_name}")
    
    # Generate signals
    signals, stop_loss, take_profit = strategy.generate_signals(data)
    
    # Initialize backtest engine
    engine = BacktestEngine(
        initial_capital=kwargs.get('capital', 100000),
        commission=kwargs.get('commission', 0.001),
        slippage=kwargs.get('slippage', 0.0005)
    )
    
    # Run backtest
    for i in range(len(data)):
        date = data.index[i]
        row = data.iloc[i]
        signal = signals.iloc[i]
        
        # Check stops first
        engine.check_stops(date, row['high'], row['low'], row['close'])
        
        # Execute signal
        if signal != 0:
            engine.execute_trade(
                date=date,
                price=row['close'],
                signal=signal,
                stop_loss=stop_loss.iloc[i] if signal == 1 else None,
                take_profit=take_profit.iloc[i] if signal == 1 else None,
                position_size=kwargs.get('position_size', 0.95)
            )
        
        # Update equity
        engine.update_equity(row['close'])
    
    # Close any open position
    if engine.position != 0:
        last_date = data.index[-1]
        last_price = data.iloc[-1]['close']
        engine._close_position(last_date, last_price, 'END')
    
    # Calculate metrics
    return engine.calculate_metrics(data.index)


def optimize_grid_search(data: pd.DataFrame, strategy_name: str) -> List[Tuple[Dict, float]]:
    """Grid search optimization"""
    
    print("\n🔍 Running Grid Search Optimization...")
    print("This may take a few minutes...\n")
    
    results = []
    
    if strategy_name == 'trend':
        fast_range = [10, 20, 30]
        slow_range = [30, 50, 100]
        atr_range = [1.5, 2.0, 2.5]
        
        total = len(fast_range) * len(slow_range) * len(atr_range)
        count = 0
        
        for fast in fast_range:
            for slow in slow_range:
                if fast >= slow:
                    continue
                for atr in atr_range:
                    count += 1
                    print(f"Progress: {count}/{total} - Testing fast={fast}, slow={slow}, atr={atr}", end='\r')
                    
                    try:
                        result = run_backtest(data, strategy_name, fast=fast, slow=slow, atr_stop=atr)
                        params = {'fast': fast, 'slow': slow, 'atr_stop': atr}
                        results.append((params, result.sharpe_ratio))
                    except:
                        pass
    
    elif strategy_name == 'meanrev':
        rsi_range = [10, 14, 20]
        buy_range = [20, 30, 40]
        sell_range = [60, 70, 80]
        
        total = len(rsi_range) * len(buy_range) * len(sell_range)
        count = 0
        
        for rsi in rsi_range:
            for buy in buy_range:
                for sell in sell_range:
                    count += 1
                    print(f"Progress: {count}/{total} - Testing rsi={rsi}, buy={buy}, sell={sell}", end='\r')
                    
                    try:
                        result = run_backtest(data, strategy_name, rsi_period=rsi, buy_below=buy, sell_above=sell)
                        params = {'rsi_period': rsi, 'buy_below': buy, 'sell_above': sell}
                        results.append((params, result.sharpe_ratio))
                    except:
                        pass
    
    print("\n")
    return sorted(results, key=lambda x: x[1], reverse=True)


def optimize_genetic(data: pd.DataFrame, strategy_name: str, generations: int = 20, population: int = 50) -> List[Tuple[Dict, float]]:
    """Genetic algorithm optimization"""
    
    print(f"\n🧬 Running Genetic Algorithm Optimization...")
    print(f"Generations: {generations}, Population: {population}\n")
    
    def random_params(strategy):
        if strategy == 'trend':
            return {
                'fast': np.random.randint(5, 30),
                'slow': np.random.randint(30, 100),
                'atr_stop': np.random.uniform(1.0, 3.0)
            }
        else:  # meanrev
            return {
                'rsi_period': np.random.randint(10, 20),
                'buy_below': np.random.uniform(20, 40),
                'sell_above': np.random.uniform(60, 80)
            }
    
    def evaluate(params):
        try:
            result = run_backtest(data, strategy_name, **params)
            return result.sharpe_ratio
        except:
            return -999
    
    # Initialize population
    population_list = [random_params(strategy_name) for _ in range(population)]
    
    for gen in range(generations):
        # Evaluate fitness
        fitness = [(p, evaluate(p)) for p in population_list]
        fitness.sort(key=lambda x: x[1], reverse=True)
        
        print(f"Generation {gen+1}/{generations} - Best Sharpe: {fitness[0][1]:.3f}", end='\r')
        
        # Select top 20%
        elite_size = max(2, population // 5)
        elite = [p for p, f in fitness[:elite_size]]
        
        # Create next generation
        new_population = elite.copy()
        
        while len(new_population) < population:
            # Crossover
            parent1, parent2 = np.random.choice(elite, 2, replace=False)
            child = {}
            
            for key in parent1.keys():
                child[key] = parent1[key] if np.random.random() > 0.5 else parent2[key]
            
            # Mutation
            if np.random.random() < 0.3:
                mutate_key = np.random.choice(list(child.keys()))
                if strategy_name == 'trend':
                    if mutate_key == 'fast':
                        child[mutate_key] = np.clip(child[mutate_key] + np.random.randint(-5, 6), 5, 30)
                    elif mutate_key == 'slow':
                        child[mutate_key] = np.clip(child[mutate_key] + np.random.randint(-10, 11), 30, 100)
                    else:
                        child[mutate_key] = np.clip(child[mutate_key] + np.random.uniform(-0.5, 0.5), 1.0, 3.0)
                else:
                    if mutate_key == 'rsi_period':
                        child[mutate_key] = np.clip(child[mutate_key] + np.random.randint(-3, 4), 10, 20)
                    else:
                        child[mutate_key] = np.clip(child[mutate_key] + np.random.uniform(-5, 5), 20, 80)
            
            new_population.append(child)
        
        population_list = new_population
    
    print("\n")
    
    # Final evaluation
    final_results = [(p, evaluate(p)) for p in population_list]
    return sorted(final_results, key=lambda x: x[1], reverse=True)


def plot_results(result: BacktestResult, data: pd.DataFrame):
    """Plot equity curve and price chart"""
    
    if not PLOTLY_AVAILABLE:
        print("⚠️  Plotly not installed. Run: pip install plotly")
        return
    
    fig = make_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.03,
        subplot_titles=('Price Chart', 'Equity Curve'),
        row_heights=[0.6, 0.4]
    )
    
    # Price chart
    fig.add_trace(
        go.Scatter(x=data.index, y=data['close'], name='Price', line=dict(color='#00ff88')),
        row=1, col=1
    )
    
    # Add trade markers
    for trade in result.trades:
        fig.add_trace(
            go.Scatter(
                x=[trade.entry_date],
                y=[trade.entry_price],
                mode='markers',
                marker=dict(symbol='triangle-up', size=10, color='lime'),
                name='Entry',
                showlegend=False
            ),
            row=1, col=1
        )
        fig.add_trace(
            go.Scatter(
                x=[trade.exit_date],
                y=[trade.exit_price],
                mode='markers',
                marker=dict(
                    symbol='triangle-down',
                    size=10,
                    color='red' if trade.pnl < 0 else 'green'
                ),
                name='Exit',
                showlegend=False
            ),
            row=1, col=1
        )
    
    # Equity curve
    fig.add_trace(
        go.Scatter(
            x=result.equity_curve.index,
            y=result.equity_curve,
            name='Equity',
            line=dict(color='#00aaff')
        ),
        row=2, col=1
    )
    
    fig.update_layout(
        title='Backtest Results',
        template='plotly_dark',
        height=800,
        showlegend=True
    )
    
    fig.update_xaxes(title_text="Date", row=2, col=1)
    fig.update_yaxes(title_text="Price", row=1, col=1)
    fig.update_yaxes(title_text="Equity ($)", row=2, col=1)
    
    fig.show()


def save_results(result: BacktestResult, output_dir: str = '.'):
    """Save results to CSV files"""
    
    output_path = Path(output_dir)
    
    # Save equity curve
    equity_df = result.equity_curve.to_frame('equity')
    equity_path = output_path / 'equity_curve.csv'
    equity_df.to_csv(equity_path)
    print(f"✅ Saved equity curve: {equity_path}")
    
    # Save trades
    if result.trades:
        trades_data = []
        for trade in result.trades:
            trades_data.append({
                'entry_date': trade.entry_date,
                'exit_date': trade.exit_date,
                'entry_price': trade.entry_price,
                'exit_price': trade.exit_price,
                'shares': trade.shares,
                'pnl': trade.pnl,
                'pnl_pct': trade.pnl_pct,
                'side': trade.side,
                'exit_reason': trade.exit_reason
            })
        
        trades_df = pd.DataFrame(trades_data)
        trades_path = output_path / 'fills.csv'
        trades_df.to_csv(trades_path, index=False)
        print(f"✅ Saved trades: {trades_path}")


def main():
    parser = argparse.ArgumentParser(
        description='Quantitative Trading Simulator',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python quant_sim.py --csv data.csv --strategy trend
  python quant_sim.py --csv data.csv --strategy trend --fast 10 --slow 30 --plot
  python quant_sim.py --csv data.csv --strategy meanrev --buy-below 30 --sell-above 70
  python quant_sim.py --csv data.csv --strategy trend --opt grid
  python quant_sim.py --csv data.csv --strategy meanrev --opt ga
        """
    )
    
    # Required arguments
    parser.add_argument('--csv', required=True, help='Path to CSV file with OHLCV data')
    parser.add_argument('--strategy', required=True, choices=['trend', 'meanrev'],
                       help='Trading strategy to use')
    
    # Strategy parameters - Trend
    parser.add_argument('--fast', type=int, default=20, help='Fast MA period (trend)')
    parser.add_argument('--slow', type=int, default=50, help='Slow MA period (trend)')
    parser.add_argument('--atr-stop', type=float, default=2.0, help='ATR stop multiplier (trend)')
    parser.add_argument('--risk-per-trade', type=float, default=0.02, help='Risk per trade (trend)')
    
    # Strategy parameters - Mean Reversion
    parser.add_argument('--rsi-period', type=int, default=14, help='RSI period (meanrev)')
    parser.add_argument('--buy-below', type=float, default=30, help='RSI buy threshold (meanrev)')
    parser.add_argument('--sell-above', type=float, default=70, help='RSI sell threshold (meanrev)')
    parser.add_argument('--stop-pct', type=float, default=0.02, help='Stop loss % (meanrev)')
    
    # Optimization
    parser.add_argument('--opt', choices=['grid', 'ga'], help='Run optimization')
    
    # Other options
    parser.add_argument('--capital', type=float, default=100000, help='Initial capital')
    parser.add_argument('--commission', type=float, default=0.001, help='Commission rate')
    parser.add_argument('--slippage', type=float, default=0.0005, help='Slippage rate')
    parser.add_argument('--plot', action='store_true', help='Plot results (requires plotly)')
    
    args = parser.parse_args()
    
    try:
        # Load data
        print(f"📊 Loading data from: {args.csv}")
        data = load_data(args.csv)
        print(f"✅ Loaded {len(data)} bars from {data.index[0]} to {data.index[-1]}")
        
        # Run optimization or single backtest
        if args.opt:
            if args.opt == 'grid':
                results = optimize_grid_search(data, args.strategy)
            else:
                results = optimize_genetic(data, args.strategy)
            
            # Print top 10 results
            print("\n" + "="*80)
            print("TOP 10 PARAMETER COMBINATIONS")
            print("="*80)
            print(f"{'Rank':<6} {'Sharpe':<10} {'Parameters'}")
            print("-"*80)
            
            for i, (params, sharpe) in enumerate(results[:10], 1):
                param_str = ', '.join([f"{k}={v:.2f}" if isinstance(v, float) else f"{k}={v}" 
                                      for k, v in params.items()])
                print(f"{i:<6} {sharpe:<10.3f} {param_str}")
            
            print("="*80)
            
            # Run backtest with best parameters
            print(f"\n🚀 Running backtest with best parameters...")
            best_params, best_sharpe = results[0]
            result = run_backtest(data, args.strategy, **best_params, capital=args.capital,
                                commission=args.commission, slippage=args.slippage)
        
        else:
            # Single backtest with provided parameters
            print(f"\n🚀 Running backtest...")
            
            params = {
                'capital': args.capital,
                'commission': args.commission,
                'slippage': args.slippage
            }
            
            if args.strategy == 'trend':
                params.update({
                    'fast': args.fast,
                    'slow': args.slow,
                    'atr_stop': args.atr_stop,
                    'risk_per_trade': args.risk_per_trade
                })
            else:
                params.update({
                    'rsi_period': args.rsi_period,
                    'buy_below': args.buy_below,
                    'sell_above': args.sell_above,
                    'stop_pct': args.stop_pct
                })
            
            result = run_backtest(data, args.strategy, **params)
        
        # Print results
        result.print_summary()
        
        # Save results
        save_results(result)
        
        # Plot if requested
        if args.plot:
            plot_results(result, data)
    
    except Exception as e:
        print(f"\n❌ Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
