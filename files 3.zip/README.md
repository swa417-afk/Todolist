# 📈 Quant-Sim: Fast Quantitative Trading Simulator

Production-ready backtesting engine with CLI interface for quantitative trading strategies.

---

## 🚀 Quick Start

### 1. Create Project Folder

```bash
mkdir quant-sim
cd quant-sim
```

### 2. Setup Virtual Environment

**macOS / Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

**Windows (PowerShell):**
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 3. Install Dependencies

```bash
pip install pandas numpy

# Optional (for charts):
pip install plotly
```

### 4. Configure VS Code

**Set Python Interpreter:**
1. Press `Cmd+Shift+P` (Mac) / `Ctrl+Shift+P` (Windows)
2. Type: "Python: Select Interpreter"
3. Choose: `.venv/bin/python` or `.venv\Scripts\python.exe`

**Recommended Extensions:**
- Python (by Microsoft)
- Pylance

---

## 📊 Usage

### Basic Trend Strategy

```bash
python quant_sim.py --csv data.csv --strategy trend
```

### Trend Strategy with Custom Parameters

```bash
python quant_sim.py --csv data.csv --strategy trend --fast 10 --slow 30 --atr-stop 2.5 --risk-per-trade 0.01
```

### Mean Reversion Strategy

```bash
python quant_sim.py --csv data.csv --strategy meanrev --buy-below 30 --sell-above 70 --stop-pct 0.03
```

### Plot Equity Curve (Requires Plotly)

```bash
python quant_sim.py --csv data.csv --strategy trend --plot
```

---

## 🔧 Optimization

### Grid Search Optimization

```bash
python quant_sim.py --csv data.csv --strategy trend --opt grid
```

Automatically tests combinations of:
- Fast MA: 10, 20, 30
- Slow MA: 30, 50, 100
- ATR Stop: 1.5, 2.0, 2.5

### Genetic Algorithm Optimization

```bash
python quant_sim.py --csv data.csv --strategy meanrev --opt ga
```

Evolves optimal parameters over 20 generations with population of 50.

---

## 📁 File Structure

```
quant-sim/
├── quant_sim.py          # Main simulator
├── data.csv              # OHLCV data
├── equity_curve.csv      # Output: Equity curve
├── fills.csv             # Output: Trade log
└── .venv/                # Virtual environment
```

---

## 📋 CSV Format

Your CSV must contain these columns:

```csv
timestamp,open,high,low,close,volume
2025-01-01,100,105,99,104,1000
2025-01-02,104,106,101,102,1100
...
```

**Required Columns:**
- `timestamp` - Date/time (any format pandas can parse)
- `open` - Opening price
- `high` - High price
- `low` - Low price
- `close` - Closing price
- `volume` - (optional)

---

## 🎯 Strategies

### 1. Trend Following (`--strategy trend`)

Moving average crossover with ATR-based stops.

**Parameters:**
- `--fast` (default: 20) - Fast MA period
- `--slow` (default: 50) - Slow MA period
- `--atr-stop` (default: 2.0) - ATR stop multiplier
- `--risk-per-trade` (default: 0.02) - Risk per trade

**Logic:**
- Buy when fast MA crosses above slow MA
- Sell when fast MA crosses below slow MA
- Stop loss: Entry price - (ATR × multiplier)
- Take profit: Entry price + (ATR × multiplier × 2)

### 2. Mean Reversion (`--strategy meanrev`)

RSI-based oversold/overbought strategy.

**Parameters:**
- `--rsi-period` (default: 14) - RSI period
- `--buy-below` (default: 30) - Buy when RSI below this
- `--sell-above` (default: 70) - Sell when RSI above this
- `--stop-pct` (default: 0.02) - Stop loss percentage

**Logic:**
- Buy when RSI < buy_below (oversold)
- Sell when RSI > sell_above (overbought)
- Fixed percentage stops

---

## 📊 Performance Metrics

The simulator calculates:

**Performance:**
- Total Return (%)
- Annual Return (%)
- Sharpe Ratio
- Sortino Ratio
- Max Drawdown (%)
- Max Drawdown Duration

**Trade Statistics:**
- Total Trades
- Win Rate (%)
- Profit Factor
- Average Win/Loss
- Largest Win/Loss

---

## 📈 Output Files

### equity_curve.csv

```csv
timestamp,equity
2025-01-01,100000
2025-01-02,100500
...
```

### fills.csv

```csv
entry_date,exit_date,entry_price,exit_price,shares,pnl,pnl_pct,side,exit_reason
2025-01-05,2025-01-20,108,120,925.9,11111.11,12.35,LONG,SIGNAL
...
```

---

## 🎨 Plotting

With Plotly installed, use `--plot` to visualize:

1. **Price Chart** with entry/exit markers
2. **Equity Curve** over time

```bash
python quant_sim.py --csv data.csv --strategy trend --plot
```

---

## ⚙️ Advanced Options

### Capital & Costs

```bash
python quant_sim.py --csv data.csv --strategy trend \
  --capital 50000 \
  --commission 0.002 \
  --slippage 0.001
```

**Parameters:**
- `--capital` (default: 100000) - Initial capital
- `--commission` (default: 0.001) - Commission rate (0.1%)
- `--slippage` (default: 0.0005) - Slippage rate (0.05%)

---

## 🐛 Troubleshooting

### ❌ "No module named pandas/numpy"

**Fix:**
```bash
# Activate venv first
source .venv/bin/activate  # Mac/Linux
.\.venv\Scripts\Activate.ps1  # Windows

# Install packages
pip install pandas numpy
```

### ❌ "CSV missing timestamp/open/high/low/close"

**Fix:**
Ensure your CSV has these exact column names. If using `Date` instead of `timestamp`, rename it:

```python
import pandas as pd
df = pd.read_csv('data.csv')
df.rename(columns={'Date': 'timestamp'}, inplace=True)
df.to_csv('data.csv', index=False)
```

### ❌ "Plotly not installed"

**Fix:**
```bash
pip install plotly
```

### ❌ VS Code not finding Python interpreter

**Fix:**
1. Press `Cmd+Shift+P` / `Ctrl+Shift+P`
2. "Python: Select Interpreter"
3. Choose `.venv/bin/python`
4. Reload window: `Cmd+Shift+P` → "Developer: Reload Window"

---

## 🧪 Example Workflows

### 1. Quick Test
```bash
python quant_sim.py --csv data.csv --strategy trend
```

### 2. Optimize & Plot
```bash
# Find best parameters
python quant_sim.py --csv data.csv --strategy trend --opt grid

# Run with best params and plot
python quant_sim.py --csv data.csv --strategy trend --fast 10 --slow 30 --atr-stop 2.0 --plot
```

### 3. Compare Strategies
```bash
# Test trend
python quant_sim.py --csv data.csv --strategy trend > trend_results.txt

# Test mean reversion
python quant_sim.py --csv data.csv --strategy meanrev > meanrev_results.txt

# Compare results
diff trend_results.txt meanrev_results.txt
```

---

## 📚 Code Structure

```python
# Main Components
├── TechnicalIndicators    # SMA, EMA, RSI, ATR, Bollinger Bands
├── BacktestEngine         # Core execution engine
├── TrendStrategy          # Trend following strategy
├── MeanReversionStrategy  # Mean reversion strategy
├── optimize_grid_search   # Grid search optimization
└── optimize_genetic       # Genetic algorithm optimization
```

---

## 🎓 Tips & Best Practices

### 1. **Data Quality**
- Use clean, validated OHLCV data
- Check for gaps and missing values
- Ensure timestamps are sorted

### 2. **Parameter Selection**
- Start with defaults
- Use optimization to find better parameters
- Avoid overfitting (test on out-of-sample data)

### 3. **Risk Management**
- Keep position size reasonable (default: 95% of capital)
- Use stop losses
- Don't over-leverage

### 4. **Performance Analysis**
- Focus on Sharpe ratio (risk-adjusted returns)
- Check max drawdown (worst loss)
- Analyze win rate vs profit factor

### 5. **Optimization**
- Grid search for small parameter spaces
- Genetic algorithm for complex strategies
- Always validate on unseen data

---

## 🚀 Next Steps

1. **Get Real Data**: Download from Yahoo Finance, Alpha Vantage, or your broker
2. **Create Custom Strategies**: Extend `TrendStrategy` or `MeanReversionStrategy`
3. **Add More Indicators**: Implement MACD, Stochastic, etc.
4. **Walk-Forward Testing**: Validate on rolling windows
5. **Live Trading**: Connect to broker API (paper trading first!)

---

## 📞 Support

**Common Issues:**
- CSV format problems → Check column names
- Package not found → Activate venv first
- VS Code interpreter → Select .venv Python

**Need Help?**
- Read error messages carefully
- Check CSV format matches example
- Verify venv is activated

---

## 📝 License

MIT License - Free to use and modify

---

**Happy Backtesting! 📈🚀**
