# VS Code Setup Guide for Quant-Sim

## 📁 Step 1: Create Project Folder

```bash
mkdir quant-sim
cd quant-sim
```

Copy these files into the folder:
- `quant_sim.py`
- `data.csv`
- `requirements.txt`

---

## 🔧 Step 2: Open in VS Code

### Option A: From Command Line
```bash
code .
```

### Option B: From VS Code
1. Open VS Code
2. File → Open Folder...
3. Select `quant-sim` folder

---

## 🐍 Step 3: Install Python Extensions

VS Code will prompt you to install recommended extensions. Click **"Install"** or:

1. Press `Cmd+Shift+X` (Mac) / `Ctrl+Shift+X` (Windows)
2. Search for: **Python** (by Microsoft)
3. Click **Install**
4. Also install: **Pylance** (usually auto-installs)

---

## 🌐 Step 4: Create Virtual Environment

### In VS Code Terminal

Open terminal: **Terminal → New Terminal** (or `` Ctrl+` ``)

**macOS / Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

**Windows (PowerShell):**
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

**Windows (Command Prompt):**
```cmd
py -m venv .venv
.venv\Scripts\activate.bat
```

You should see `(.venv)` in your terminal prompt.

---

## 📦 Step 5: Install Dependencies

```bash
pip install -r requirements.txt
```

Or manually:
```bash
pip install pandas numpy
pip install plotly  # Optional for charts
```

---

## 🎯 Step 6: Select Python Interpreter

**Critical step for VS Code to recognize your packages!**

1. Press `Cmd+Shift+P` (Mac) / `Ctrl+Shift+P` (Windows)
2. Type: `Python: Select Interpreter`
3. Choose the interpreter that shows: `.venv` or `.venv/bin/python`

**If you don't see .venv:**
1. Click "Enter interpreter path..."
2. Browse to: `.venv/bin/python` (Mac/Linux) or `.venv\Scripts\python.exe` (Windows)

**Verify it worked:**
- Look at bottom-left of VS Code
- Should show: `Python 3.x.x ('.venv': venv)`

---

## ▶️ Step 7: Run Your First Backtest

### Method 1: Using Terminal

```bash
python quant_sim.py --csv data.csv --strategy trend
```

### Method 2: Using VS Code Run Button

1. Open `quant_sim.py`
2. Click the ▶️ (play) button in top-right
3. Or press `F5` to debug

**Note:** To pass arguments when using F5:
1. Create `.vscode/launch.json` (see below)
2. Add arguments there

---

## 🐛 Step 8: Debug Configuration (Optional)

Create `.vscode/launch.json`:

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Python: Trend Strategy",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/quant_sim.py",
            "args": [
                "--csv", "data.csv",
                "--strategy", "trend"
            ],
            "console": "integratedTerminal"
        },
        {
            "name": "Python: Mean Reversion",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/quant_sim.py",
            "args": [
                "--csv", "data.csv",
                "--strategy", "meanrev"
            ],
            "console": "integratedTerminal"
        },
        {
            "name": "Python: Optimize Grid",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/quant_sim.py",
            "args": [
                "--csv", "data.csv",
                "--strategy", "trend",
                "--opt", "grid"
            ],
            "console": "integratedTerminal"
        }
    ]
}
```

Now you can:
1. Press `F5`
2. Select configuration from dropdown
3. Debug with breakpoints!

---

## 🎨 VS Code Features to Use

### 1. IntelliSense (Auto-complete)

Type `pd.` and see all pandas functions autocomplete.

**If not working:**
- Check interpreter is set to `.venv`
- Reload window: `Cmd+Shift+P` → "Developer: Reload Window"

### 2. Go to Definition

- Click on a function while holding `Cmd` (Mac) / `Ctrl` (Windows)
- Or right-click → "Go to Definition"

### 3. Code Formatting

- Press `Shift+Alt+F` (Windows) / `Shift+Option+F` (Mac)
- Formats your code automatically

**Enable format on save:**
1. Settings (`Cmd+,` / `Ctrl+,`)
2. Search: "format on save"
3. Check the box

### 4. Terminal Split

- Click + button in terminal
- Or `Cmd+Shift+5` / `Ctrl+Shift+5`
- Run multiple commands side-by-side

### 5. Breakpoints for Debugging

1. Click left of line number (red dot appears)
2. Press `F5` to start debugging
3. Use debug controls:
   - `F5` - Continue
   - `F10` - Step Over
   - `F11` - Step Into
   - `Shift+F11` - Step Out

---

## ✅ Verification Checklist

Before running your first backtest, verify:

- [ ] Virtual environment created (`.venv` folder exists)
- [ ] Virtual environment activated (`(.venv)` in terminal)
- [ ] Dependencies installed (`pip list` shows pandas, numpy)
- [ ] VS Code interpreter set to `.venv`
- [ ] Bottom-left shows: `Python 3.x.x ('.venv': venv)`
- [ ] No import errors when opening `quant_sim.py`

---

## 🚨 Common Issues & Fixes

### ❌ "No module named 'pandas'"

**Cause:** Packages installed outside venv, or wrong interpreter.

**Fix:**
```bash
# 1. Make sure venv is activated
source .venv/bin/activate  # Mac/Linux
.\.venv\Scripts\Activate.ps1  # Windows

# 2. Reinstall packages
pip install pandas numpy

# 3. Verify VS Code interpreter is set to .venv
```

### ❌ IntelliSense not working

**Fix:**
1. `Cmd+Shift+P` → "Python: Select Interpreter" → Choose `.venv`
2. `Cmd+Shift+P` → "Developer: Reload Window"
3. Close and reopen `quant_sim.py`

### ❌ "Permission denied" when activating venv

**Windows PowerShell Fix:**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

Then try activating again.

### ❌ Terminal shows wrong Python version

**Fix:**
```bash
# Close and reopen terminal
# Or manually activate:
source .venv/bin/activate
```

### ❌ Code runs in system Python instead of venv

**Fix:**
1. Check bottom-left of VS Code - should show `.venv`
2. If not, select correct interpreter
3. Restart terminal or reload window

---

## 🎓 Pro Tips

### 1. Use Terminal Keyboard Shortcuts

- `` Ctrl+` `` - Toggle terminal
- `Cmd+Shift+5` / `Ctrl+Shift+5` - Split terminal

### 2. Multi-Cursor Editing

- Hold `Alt` and click to add cursors
- `Cmd+D` / `Ctrl+D` - Select next occurrence

### 3. Command Palette

- `Cmd+Shift+P` / `Ctrl+Shift+P` - Access any command
- Type what you want, no memorizing shortcuts!

### 4. File Quick Open

- `Cmd+P` / `Ctrl+P` - Quick open file
- Start typing filename

### 5. Search in Files

- `Cmd+Shift+F` / `Ctrl+Shift+F` - Search across all files

---

## 📊 Example VS Code Workflow

1. **Open project**: `code .`
2. **Activate venv in terminal**: `source .venv/bin/activate`
3. **Edit code**: Make changes to `quant_sim.py`
4. **Format code**: `Shift+Alt+F`
5. **Run backtest**: `python quant_sim.py --csv data.csv --strategy trend`
6. **View results**: Check `equity_curve.csv` and `fills.csv`
7. **Debug if needed**: Set breakpoints, press `F5`

---

## 🎯 Next Steps

1. **Run the example**: `python quant_sim.py --csv data.csv --strategy trend`
2. **Try optimization**: `python quant_sim.py --csv data.csv --strategy trend --opt grid`
3. **Plot results**: `python quant_sim.py --csv data.csv --strategy trend --plot`
4. **Modify parameters**: Experiment with `--fast`, `--slow`, etc.
5. **Add your own data**: Replace `data.csv` with real market data

---

## 📚 Additional Resources

- [VS Code Python Tutorial](https://code.visualstudio.com/docs/python/python-tutorial)
- [pandas Documentation](https://pandas.pydata.org/docs/)
- [Plotly Charts](https://plotly.com/python/)

---

**Ready to backtest! 🚀📈**
